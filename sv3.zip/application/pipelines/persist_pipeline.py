# application/pipelines/persist_pipeline.py — PARCHE sv3
"""
ELIMINACIÓN de la llamada fire-and-forget a sv6.

ANTES sv3 hacía al final del persist (si había selected_contrato_codigo
y NO era duplicado):

    httpx.post(VALUATION_API_URL + "/v1/valuation/run-async", ...)

DESPUÉS: nada. sv3 solo persiste. El orquestador (sv7) lee el resultado
y decide si dispara sv6.

Razones:
  1. Centralizar orquestación en un único lugar (sv7).
  2. Eliminar el acoplamiento sv3 → sv6 (sv3 ya no conoce sv6).
  3. Resolver el bug §13.2: cuando sv4 cambia el contrato seleccionado
     y guarda, hoy sv3 NO se entera → no dispara re-valoración.
     A partir de ahora sv4 emite event a sv7 directamente.

NOTA: el endpoint PATCH /v1/albaranes/{id}/selected-contrato puede
mantener temporalmente el flag ``trigger_valuation`` en su firma
durante una ventana de transición, pero IGNORARLO. Cuando sv7 esté
estable, se elimina del schema.

Este archivo es un "patrón de cambio" — adapta el persist_pipeline.py
real reemplazando el bloque que disparaba sv6 por nada (o por un
log explícito de "delegado a sv7").
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


# ============================================================== #
# DIFF (pseudocódigo): qué borrar exactamente del persist_pipeline.
# ============================================================== #
#
# Buscar en application/pipelines/persist_pipeline.py el bloque
# similar a este:
#
# -    if (
# -        result.selected_contrato_codigo
# -        and not result.duplicate
# -        and self._valuation_trigger is not None
# -    ):
# -        try:
# -            self._valuation_trigger.fire(
# -                document_id=result.document_id,
# -                codigo_contrato=result.selected_contrato_codigo,
# -            )
# -            logger.info(
# -                "[persist][valuation] fire-and-forget OK doc=%s",
# -                result.document_id,
# -            )
# -        except Exception as exc:
# -            logger.warning(
# -                "[persist][valuation] fire-and-forget falló: %s",
# -                exc,
# -            )
#
# Sustituir por:
#
# +    # La valoración se delega al orquestador (sv7). sv3 ya no la
# +    # dispara directamente.
# +    logger.info(
# +        "[persist] doc=%s contratos=%d selected=%s duplicate=%s "
# +        "(valoración delegada a orquestador)",
# +        result.document_id,
# +        result.contratos_count,
# +        result.selected_contrato_codigo,
# +        result.duplicate,
# +    )
#
# Y en el composition root (build_app de sv3), eliminar el wiring del
# HttpValuationTrigger / equivalente:
#
# -    valuation_trigger = HttpValuationTrigger(
# -        base_url=settings.valuation_api_base_url,
# -        ...
# -    )
# -    persist_pipeline = PersistPipeline(
# -        ...,
# -        valuation_trigger=valuation_trigger,
# -    )
#
# +    persist_pipeline = PersistPipeline(
# +        ...,
# +        # valuation_trigger eliminado: lo gestiona sv7.
# +    )
